document.addEventListener("DOMContentLoaded", () => {
    const toggleDarkModeButton = document.getElementById("toggleDarkMode");
    const body = document.body;

    toggleDarkModeButton.addEventListener("click", () => {
        body.classList.toggle("dark-mode");
        localStorage.setItem("darkMode", body.classList.contains("dark-mode"));
    });

    if (localStorage.getItem("darkMode") === "true") {
        body.classList.add("dark-mode");
    }
});

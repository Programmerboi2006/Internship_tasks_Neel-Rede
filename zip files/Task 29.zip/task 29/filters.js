document.addEventListener("DOMContentLoaded", () => {
    const categoryFilter = document.createElement("select");
    categoryFilter.innerHTML = `
        <option value="All">All</option>
        <option value="Food">Food</option>
        <option value="Transport">Transport</option>
        <option value="Shopping">Shopping</option>
        <option value="Entertainment">Entertainment</option>
    `;
    document.querySelector(".expense-list").prepend(categoryFilter);

    categoryFilter.addEventListener("change", () => {
        const selectedCategory = categoryFilter.value;
        const filteredExpenses = selectedCategory === "All" ? 
            expenses : 
            expenses.filter(expense => expense.category === selectedCategory);
        
        document.getElementById("expenses").innerHTML = "";
        filteredExpenses.forEach((expense, index) => {
            const li = document.createElement("li");
            li.innerHTML = `${expense.category}: $${expense.amount} - ${expense.description} 
                <button onclick="deleteExpense(${index})">❌</button>`;
            document.getElementById("expenses").appendChild(li);
        });
    });
});

document.addEventListener("DOMContentLoaded", () => {
    const amountInput = document.getElementById("amount");
    const categoryInput = document.getElementById("category");
    const descriptionInput = document.getElementById("description");
    const addExpenseButton = document.getElementById("addExpense");
    const expenseList = document.getElementById("expenses");
    const totalAmountDisplay = document.getElementById("totalAmount");

    let expenses = JSON.parse(localStorage.getItem("expenses")) || [];

    function formatCurrency(amount) {
        return `₹${amount.toFixed(2)}`;
    }

    function updateExpenses() {
        expenseList.innerHTML = "";
        let total = 0;

        expenses.forEach((expense, index) => {
            total += expense.amount;
            const li = document.createElement("li");
            li.innerHTML = `
                <span class="expense-category">${expense.category}:</span> 
                <span class="expense-amount">${formatCurrency(expense.amount)}</span> - 
                <span class="expense-description">${expense.description}</span>
                <button onclick="deleteExpense(${index})">❌</button>
            `;
            expenseList.appendChild(li);
        });

        totalAmountDisplay.textContent = formatCurrency(total);
        localStorage.setItem("expenses", JSON.stringify(expenses));
    }

    addExpenseButton.addEventListener("click", () => {
        const amount = parseFloat(amountInput.value);
        const category = categoryInput.value;
        const description = descriptionInput.value.trim();

        if (!amount || amount <= 0 || !description) {
            alert("Please enter valid expense details.");
            return;
        }

        expenses.push({ amount, category, description });
        updateExpenses();
        amountInput.value = "";
        descriptionInput.value = "";
    });

    window.deleteExpense = (index) => {
        expenses.splice(index, 1);
        updateExpenses();
    };

    updateExpenses();
});

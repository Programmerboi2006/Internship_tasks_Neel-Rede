document.addEventListener("DOMContentLoaded", () => {
    function updateChart() {
        const categories = {};
        expenses.forEach(expense => {
            categories[expense.category] = (categories[expense.category] || 0) + expense.amount;
        });

        new Chart(document.getElementById("expenseChart"), {
            type: "bar",
            data: {
                labels: Object.keys(categories),
                datasets: [{ data: Object.values(categories), backgroundColor: "blue" }]
            }
        });
    }

    updateChart();
});

from pydantic import BaseModel
from typing import Optional

class UserCreate(BaseModel):
    first_name: str
    last_name: str
    email: str
    account_balance: float

class StockCreate(BaseModel):
    ticker_symbol: str
    company_name: str
    current_price: float
    market_cap: float

class OrderCreate(BaseModel):
    user_id: int
    stock_id: int
    order_type: str
    quantity: int
    price_per_share: float

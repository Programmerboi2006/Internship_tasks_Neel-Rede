from sqlalchemy import Column, Integer, String, DECIMAL, DateTime, Enum, ForeignKey
from sqlalchemy.sql import func
from .database import Base

class User(Base):
    __tablename__ = "users"
    user_id = Column(Integer, primary_key=True, index=True)
    first_name = Column(String(100))
    last_name = Column(String(100))
    email = Column(String(100), unique=True)
    account_balance = Column(DECIMAL(15,2))
    registration_date = Column(DateTime(timezone=True), server_default=func.now())

class Stock(Base):
    __tablename__ = "stocks"
    stock_id = Column(Integer, primary_key=True, index=True)
    ticker_symbol = Column(String(10), unique=True)
    company_name = Column(String(255))
    current_price = Column(DECIMAL(10,2))
    market_cap = Column(DECIMAL(20,2))

class Order(Base):
    __tablename__ = "orders"
    order_id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.user_id"))
    stock_id = Column(Integer, ForeignKey("stocks.stock_id"))
    order_type = Column(Enum('buy', 'sell'))
    quantity = Column(Integer)
    price_per_share = Column(DECIMAL(10,2))
    order_status = Column(Enum('pending', 'executed', 'canceled'), default='pending')
    order_time = Column(DateTime(timezone=True), server_default=func.now())

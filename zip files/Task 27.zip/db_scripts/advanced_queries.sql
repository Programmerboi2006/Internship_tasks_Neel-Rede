SELECT s.ticker_symbol, COUNT(o.order_id) AS trade_count
FROM orders o
JOIN stocks s ON o.stock_id = s.stock_id
WHERE o.order_time >= NOW() - INTERVAL 1 DAY
GROUP BY s.ticker_symbol
ORDER BY trade_count DESC
LIMIT 5;

SELECT u.user_id, SUM((s.current_price - up.average_purchase_price) * up.quantity_owned) AS profit_loss
FROM user_portfolio up
JOIN users u ON up.user_id = u.user_id
JOIN stocks s ON up.stock_id = s.stock_id
GROUP BY u.user_id;

SELECT o.order_id, u.first_name, u.account_balance, (o.quantity * o.price_per_share) AS trade_value
FROM orders o
JOIN users u ON o.user_id = u.user_id
WHERE (o.quantity * o.price_per_share) > (u.account_balance * 0.5);

SELECT u.user_id, COUNT(o.order_id) AS trade_count
FROM orders o
JOIN users u ON o.user_id = u.user_id
WHERE o.order_time >= NOW() - INTERVAL 1 HOUR
GROUP BY u.user_id
HAVING trade_count > 100;

SELECT s.ticker_symbol, DATE(t.execution_time) AS trading_day, SUM(t.execution_price) AS total_volume
FROM transactions t
JOIN orders o ON t.order_id = o.order_id
JOIN stocks s ON o.stock_id = s.stock_id
GROUP BY s.ticker_symbol, trading_day;

SELECT o.*
FROM orders o
LEFT JOIN transactions t ON o.order_id = t.order_id
WHERE t.transaction_id IS NULL;

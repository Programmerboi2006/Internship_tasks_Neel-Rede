import java.util.List;
import java.sql.Connection;

public class Main {
    public static void main(String[] args) {
        ProductDAO dao = new ProductDAO();

        // Create (Add Product)
        Product newProduct = new Product("Laptop", "Gaming laptop", 1200.99, 5);
        dao.addProduct(newProduct);

        // Read (Display All Products)
        System.out.println("All Products:");
        List<Product> products = dao.getAllProducts();
        for (Product p : products) {
            System.out.println(p.getId() + " | " + p.getName() + " | $" + p.getPrice());
        }

        // Read (Get by ID)
        Product fetchedProduct = dao.getProductById(1);
        if (fetchedProduct != null) {
            System.out.println("\nFetched Product: " + fetchedProduct.getName());
        }

        // Update (Modify Product)
        fetchedProduct.setPrice(1100.00);
        dao.updateProduct(fetchedProduct);

        // Delete (Remove Product)
        dao.deleteProduct(1);
    }
}

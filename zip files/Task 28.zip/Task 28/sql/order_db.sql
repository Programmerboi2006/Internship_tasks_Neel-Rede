-- Create the database if it doesn't exist
CREATE DATABASE IF NOT EXISTS order_db;

-- Select the database to use
USE order_db;

-- Drop the table if it exists (for development/testing purposes)
DROP TABLE IF EXISTS orders;

-- Create the orders table
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_name VARCHAR(255) NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Optionally, insert some initial data for testing
INSERT INTO orders (product_name, quantity, price) VALUES
    ('Samosa', 10, 15.00),
    ('Jalebi', 5, 25.00),
    ('Masala Chai', 2, 10.00);
import java.sql.*;
import java.util.Scanner;

public class OrderService {
    private final Scanner scanner = new Scanner(System.in);

    public void placeOrder() {
        try (Connection conn = DBConnection.getConnection()) {
            System.out.print("Enter Product Name: ");
            String productName = scanner.nextLine();
            System.out.print("Enter Quantity: ");
            int quantity = Integer.parseInt(scanner.nextLine());
            System.out.print("Enter Price: ");
            double price = Double.parseDouble(scanner.nextLine());

            String sql = "INSERT INTO orders (product_name, quantity, price) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, productName);
            stmt.setInt(2, quantity);
            stmt.setDouble(3, price);
            stmt.executeUpdate();

            System.out.println("Order placed successfully!");
        } catch (Exception e) {
            System.out.println("Failed to place order. " + e.getMessage());
        }
    }

    public void viewOrders() {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM orders";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            System.out.println("\n=== Order History ===");
            System.out.printf("%-5s %-20s %-10s %-10s %-20s\n", "ID", "Product", "Quantity", "Price", "Order Date");
            System.out.println("-----------------------------------------------------------------------");
            while (rs.next()) {
                System.out.printf("%-5d %-20s %-10d %-10.2f %-20s\n",
                        rs.getInt("id"),
                        rs.getString("product_name"),
                        rs.getInt("quantity"),
                        rs.getDouble("price"),
                        rs.getTimestamp("order_date"));
            }
            System.out.println("-----------------------------------------------------------------------\n");
        } catch (Exception e) {
            System.out.println("Failed to fetch orders. " + e.getMessage());
        }
    }

    public void deleteOrder() {
        try (Connection conn = DBConnection.getConnection()) {
            System.out.print("Enter Order ID to delete: ");
            int id = Integer.parseInt(scanner.nextLine());

            String sql = "DELETE FROM orders WHERE id=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Order deleted successfully!");
            } else {
                System.out.println("Order ID not found.");
            }
        } catch (Exception e) {
            System.out.println("Failed to delete order. " + e.getMessage());
        }
    }
}

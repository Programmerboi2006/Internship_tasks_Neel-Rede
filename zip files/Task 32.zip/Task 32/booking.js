const form = document.getElementById('bookingForm');
const summary = document.getElementById('summary');

form.addEventListener('input', () => {
  const name = form.name.value;
  const destination = form.destination.value;
  const checkin = form.checkin.value;
  const checkout = form.checkout.value;
  const guests = form.guests.value;
  const roomType = form.roomType.value;

  if(name && destination && checkin && checkout && guests && roomType) {
    summary.innerHTML = `
      Booking for <strong>${name}</strong><br>
      Destination: <strong>${destination}</strong><br>
      Check-in: <strong>${checkin}</strong> | Check-out: <strong>${checkout}</strong><br>
      Guests: <strong>${guests}</strong> | Room: <strong>${roomType}</strong>
    `;
  }
});

form.addEventListener('submit', (e) => {
  e.preventDefault();
  alert('Booking successful! We will contact you shortly.');
  form.reset();
  summary.innerHTML = "Fill the form to see your booking summary.";
});

const teamMembers = [
  {
    name: "Alice Johnson",
    designation: "Team Lead",
    bio: "Alice is an expert in project management and frontend development.",
    photo: "Stock_image2.jpeg",
    social: { linkedin: "https://www.linkedin.com/in/neel-rede-8744962b1"}
  },
  {
    name: "Bob Smith",
    designation: "Backend Developer",
    bio: "Bob specializes in server-side technologies and databases.",
    photo: "Stock_image1.jpeg",
    social: { linkedin: "https://www.linkedin.com/in/neel-rede-8744962b1"}
  },
  {
    name: "Charlie Davis",
    designation: "UI/UX Designer",
    bio: "Charlie is passionate about creating visually appealing interfaces.",
    photo: "Stock_image4.jpeg",
    social: { linkedin: "https://www.linkedin.com/in/neel-rede-8744962b1"}
  },
];

const teamContainer = document.getElementById('team-container');

// Function to render the team cards
teamMembers.forEach(member => {
  const card = `
    <div class="team-card">
      <img src="${member.photo}" alt="${member.name}">
      <div class="team-card-body">
        <h5>${member.name}</h5>
        <p>${member.designation}</p>
        <p>${member.bio}</p>
        <div class="social-icons">
          <a href="${member.social.linkedin}" target="_blank">LinkedIn</a>
        </div>
      </div>
    </div>
  `;
  teamContainer.innerHTML += card;
});

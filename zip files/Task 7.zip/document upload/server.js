const express = require('express');
const multer = require('multer');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.get('/search', async (req, res) => {
    const { query } = req.query;
    console.log('Searching for:', query); // Debugging log
    const results = await File.find({ title: new RegExp(query, 'i') });
    console.log('Results found:', results); // Debugging log
    res.json(results);
});

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/docshare', { useNewUrlParser: true, useUnifiedTopology: true });

const fileSchema = new mongoose.Schema({
    title: String,
    fileName: String,
    uploadDate: { type: Date, default: Date.now },
});
const File = mongoose.model('File', fileSchema);

// File storage configuration
const storage = multer.diskStorage({
    destination: './uploads',
    filename: (req, file, cb) => {
        cb(null, Date.now() + '-' + file.originalname);
    },
});
const upload = multer({ storage });

// Upload endpoint
app.post('/upload', upload.single('file'), async (req, res) => {
    const file = new File({
        title: req.body.title,
        fileName: req.file.filename,
    });
    await file.save();
    res.json({ message: 'File uploaded successfully', file });
});

// Search endpoint
app.get('/search', async (req, res) => {
    const { query } = req.query;
    const results = await File.find({ title: new RegExp(query, 'i') });
    res.json(results);
});

// Download endpoint
app.get('/download/:fileName', (req, res) => {
    const filePath = path.join(__dirname, 'uploads', req.params.fileName);
    res.download(filePath);
});

// Start server
app.listen(5000, () => console.log('Server running on http://localhost:5000'));

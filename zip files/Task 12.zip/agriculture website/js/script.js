document.addEventListener("DOMContentLoaded", function() {
  console.log("Website Loaded Successfully");

  // Contact Form Submission (Just a basic alert for now)
  const form = document.querySelector(".contact-form form");
  if (form) {
      form.addEventListener("submit", function(event) {
          event.preventDefault();
          alert("Thank you for contacting us! We'll get back to you soon.");
          form.reset();
      });
  }
});

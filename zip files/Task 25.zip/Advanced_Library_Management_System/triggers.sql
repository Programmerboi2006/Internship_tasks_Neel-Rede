-- triggers.sql

-- Trigger: Auto-create fine if book is overdue
DELIMITER $$
CREATE TRIGGER create_fine_after_due
AFTER UPDATE ON loans
FOR EACH ROW
BEGIN
    IF NEW.return_date IS NULL AND NEW.due_date < CURDATE() THEN
        INSERT INTO fines (member_id, loan_id, fine_amount, paid_status)
        VALUES (NEW.member_id, NEW.loan_id, 50.00, 'unpaid'); -- INR 50 fine
    END IF;
END$$
DELIMITER ;

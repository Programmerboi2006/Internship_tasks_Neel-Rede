-- advanced_queries.sql

-- 1. Top 3 members with most overdue books
SELECT m.member_id, m.first_name, m.last_name, COUNT(*) AS overdue_books
FROM members m
JOIN loans l ON m.member_id = l.member_id
WHERE l.due_date < CURDATE() AND l.return_date IS NULL
GROUP BY m.member_id
ORDER BY overdue_books DESC
LIMIT 3;

-- 2. Total fine amount for a specific member
SELECT SUM(fine_amount) AS total_fine
FROM fines
WHERE member_id = ?; -- replace ? with actual member_id

-- 3. Books that have never been borrowed
SELECT b.book_id, b.title
FROM books b
LEFT JOIN loans l ON b.book_id = l.book_id
WHERE l.loan_id IS NULL;

-- 4. Reservations not fulfilled for more than 10 days
SELECT * FROM reservations
WHERE status = 'pending'
AND DATEDIFF(CURDATE(), reservation_date) > 10;

-- 5. Report of total fines collected in last 6 months
SELECT SUM(fine_amount) AS total_collected
FROM fines
WHERE paid_status = 'paid'
AND DATE_SUB(CURDATE(), INTERVAL 6 MONTH) <= (SELECT MAX(return_date) FROM loans WHERE loans.loan_id = fines.loan_id);

-- 6. Members who borrowed more than 10 books in last year
SELECT m.member_id, m.first_name, m.last_name, COUNT(l.loan_id) AS total_loans
FROM members m
JOIN loans l ON m.member_id = l.member_id
WHERE l.loan_date >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)
GROUP BY m.member_id
HAVING total_loans > 10;

-- 7. Top 3 most active librarians
SELECT l.librarian_id, l.first_name, l.last_name, COUNT(lo.loan_id) AS processed_loans
FROM librarians l
JOIN loans lo ON l.librarian_id = lo.processed_by
GROUP BY l.librarian_id
ORDER BY processed_loans DESC
LIMIT 3;

-- 8. Books most reserved but not borrowed
SELECT r.book_id, b.title, COUNT(r.reservation_id) AS total_reservations
FROM reservations r
JOIN books b ON r.book_id = b.book_id
LEFT JOIN loans l ON r.book_id = l.book_id
WHERE l.loan_id IS NULL
GROUP BY r.book_id
ORDER BY total_reservations DESC;

-- stored_procedures.sql

-- Stored Procedure: Mark overdue books and apply fines
DELIMITER $$
CREATE PROCEDURE mark_overdue_and_fine()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE l_loan_id INT;
    DECLARE l_member_id INT;
    DECLARE cur CURSOR FOR
        SELECT loan_id, member_id FROM loans
        WHERE due_date < CURDATE() AND return_date IS NULL;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    OPEN cur;

    read_loop: LOOP
        FETCH cur INTO l_loan_id, l_member_id;
        IF done THEN
            LEAVE read_loop;
        END IF;

        INSERT INTO fines (member_id, loan_id, fine_amount, paid_status)
        VALUES (l_member_id, l_loan_id, 50.00, 'unpaid'); -- INR 50

    END LOOP;

    CLOSE cur;
END$$
DELIMITER ;

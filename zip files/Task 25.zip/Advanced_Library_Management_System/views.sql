-- views.sql

-- View: Member borrowing history
CREATE OR REPLACE VIEW member_borrowing_history AS
SELECT m.member_id, m.first_name, m.last_name, b.title, l.loan_date, l.due_date, l.return_date
FROM members m
JOIN loans l ON m.member_id = l.member_id
JOIN books b ON l.book_id = b.book_id
ORDER BY m.member_id, l.loan_date;

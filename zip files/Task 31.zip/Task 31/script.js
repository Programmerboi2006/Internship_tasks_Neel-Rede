// Menu filtering
function filterMenu(category) {
    const items = document.querySelectorAll('.menu-item');
    items.forEach(item => {
        if (category === 'all' || item.classList.contains(category)) {
            item.style.display = 'block';
        } else {
            item.style.display = 'none';
        }
    });
}

// Reservation form validation
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('reservationForm');
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const date = document.getElementById('date').value;
            const time = document.getElementById('time').value;
            const people = parseInt(document.getElementById('people').value);

            if (!name || !email || !date || !time || isNaN(people)) {
                alert('Please fill all fields correctly.');
                return;
            }

            if (people > 10) {
                alert('For groups larger than 10, please call us directly.');
                return;
            }

            document.getElementById('confirmation').innerHTML = `
                <p>Thank you, ${name}! Your reservation for ${people} people on ${date} at ${time} has been confirmed!</p>
            `;
            form.reset();
        });
    }
});

CREATE DATABASE coming_soon;
USE coming_soon;
CREATE TABLE countdown (
    id INT AUTO_INCREMENT PRIMARY KEY,
    launch_date DATETIME NOT NULL,
    message VARCHAR(255)
);
INSERT INTO countdown (launch_date, message) 
VALUES ('2025-02-01 12:00:00', 'Website Launch');
SELECT * FROM countdown;
GRANT ALL PRIVILEGES ON coming_soon.* TO 'root'@'localhost';
FLUSH PRIVILEGES;


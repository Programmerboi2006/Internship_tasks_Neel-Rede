const INR_RATE = 83;

const products = [
  {
    id: 1,
    name: "Echo Dot",
    price: 49.99 * INR_RATE,
    description: "Smart speaker with Alexa",
    image: "file:///C:/Users/Neel%20Rede/OneDrive/Desktop/Coding/Internship/Task%2033/echo_dot.jpg"
  },
  {
    id: 2,
    name: "Wireless Headphones",
    price: 89.99 * INR_RATE,
    description: "Noise-cancelling over-ear headphones",
    image: "file:///C:/Users/Neel%20Rede/OneDrive/Desktop/Coding/Internship/Task%2033/wireless_headphones.jpg"
  },
  {
    id: 3,
    name: "Gaming Mouse",
    price: 25.99 * INR_RATE,
    description: "High precision mouse",
    image: "file:///C:/Users/Neel%20Rede/OneDrive/Desktop/Coding/Internship/Task%2033/gaming_mouse.jpg"
  },
  {
    id: 4,
    name: "Laptop Stand",
    price: 39.99 * INR_RATE,
    description: "Adjustable ergonomic laptop stand",
    image: "file:///C:/Users/Neel%20Rede/OneDrive/Desktop/Coding/Internship/Task%2033/laptop_stand.jpg"
  },
  {
    id: 5,
    name: "Bluetooth Speaker",
    price: 59.99 * INR_RATE,
    description: "Portable outdoor speaker",
    image: "file:///C:/Users/Neel%20Rede/OneDrive/Desktop/Coding/Internship/Task%2033/bluetooth_speaker.jpg"
  }
];

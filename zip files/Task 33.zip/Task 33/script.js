// Utils
function getProductById(id) {
    return products.find(p => p.id == id);
  }
  
  function displayProducts(productList) {
    const container = document.getElementById('product-grid');
    if (!container) return;
    container.innerHTML = '';
    productList.forEach(product => {
      const card = document.createElement('div');
      card.className = 'product-card';
      card.innerHTML = `
        <img src="${product.image}" />
        <p>${product.name}</p>
        <p>₹${Math.round(product.price)}</p>
      `;
      card.onclick = () => window.location.href = `product.html?id=${product.id}`;
      container.appendChild(card);
    });
  }
  
  function sortProducts(order) {
    if (order === 'low') {
      products.sort((a, b) => a.price - b.price);
    } else if (order === 'high') {
      products.sort((a, b) => b.price - a.price);
    }
    displayProducts(products);
  }
  
  function renderProductPage() {
    const id = new URLSearchParams(window.location.search).get('id');
    const product = getProductById(id);
    const container = document.getElementById('product-details');
    if (!product || !container) return;
    container.innerHTML = `
      <div class="product-card" style="max-width: 400px; margin: auto;">
        <img src="${product.image}" />
        <h3>${product.name}</h3>
        <p>${product.description}</p>
        <p><strong>$${product.price.toFixed(2)}</strong></p>
        <button onclick="addToCart(${product.id})">Add to Cart</button>
      </div>
    `;
  }
  
  function addToCart(id) {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart.push(id);
    localStorage.setItem('cart', JSON.stringify(cart));
    alert("Added to cart!");
  }
  
  function loadCart() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const list = document.getElementById('cart-list');
    const totalText = document.getElementById('total-price');
    if (!list || !totalText) return;
  
    list.innerHTML = '';
    let total = 0;
  
    cart.forEach((id, index) => {
      const product = getProductById(id);
      if (!product) return;
      const li = document.createElement('li');
      li.innerHTML = `${product.name} - $${product.price.toFixed(2)} <button onclick="removeFromCart(${index})">Remove</button>`;
      list.appendChild(li);
      total += product.price;
    });
  
    totalText.innerText = `Total: $${total.toFixed(2)}`;
  }
  
  function removeFromCart(index) {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart.splice(index, 1);
    localStorage.setItem('cart', JSON.stringify(cart));
    loadCart();
  }
  
  // Auto-run
  document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('product-grid')) displayProducts(products);
    if (document.getElementById('product-details')) renderProductPage();
    if (document.getElementById('cart-list')) loadCart();
  });
  
  // Banner rotator
  let currentBanner = 1;
  setInterval(() => {
    const banner = document.getElementById('banner-img');
    if (!banner) return;
    currentBanner = (currentBanner % 5) + 1;
    banner.src = `https://picsum.photos/1200/300?random=${currentBanner}`;
  }, 4000);
  
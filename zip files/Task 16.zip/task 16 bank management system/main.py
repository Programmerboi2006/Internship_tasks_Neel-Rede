from bank import Bank
from account import CheckingAccount, SavingsAccount
from transactions import Transaction

def main():
    bank = Bank()
    
    while True:
        print("\nWelcome to the Advanced Bank Management System!")
        print("1. Create a new account")
        print("2. View account details")
        print("3. Deposit money")
        print("4. Withdraw money")
        print("5. Transfer money")
        print("6. View transaction history")
        print("7. Exit")

        choice = input("Enter your choice (1-7): ")

        if choice == "1":
            name = input("Enter your name: ")
            pin = input("Set a 4-digit PIN: ")
            account_type = input("Enter account type (Checking/Savings): ").strip().lower()
            initial_deposit = float(input("Enter initial deposit amount: "))

            if account_type == "checking":
                account = CheckingAccount(name, pin, initial_deposit)
            elif account_type == "savings":
                account = SavingsAccount(name, pin, initial_deposit)
            else:
                print("Invalid account type!")
                continue

            bank.add_account(account)
            print(f"Account created successfully! Account Number: {account.account_number}")

        elif choice == "2":
            acc_num = int(input("Enter your account number: "))
            pin = input("Enter your PIN: ")
            account = bank.get_account(acc_num, pin)
            if account:
                account.display_details()
            else:
                print("Invalid credentials!")

        elif choice == "3":
            acc_num = int(input("Enter your account number: "))
            pin = input("Enter your PIN: ")
            account = bank.get_account(acc_num, pin)
            if account:
                amount = float(input("Enter deposit amount: "))
                account.deposit(amount)
            else:
                print("Invalid credentials!")

        elif choice == "4":
            acc_num = int(input("Enter your account number: "))
            pin = input("Enter your PIN: ")
            account = bank.get_account(acc_num, pin)
            if account:
                amount = float(input("Enter withdrawal amount: "))
                account.withdraw(amount)
            else:
                print("Invalid credentials!")

        elif choice == "5":
            sender_acc = int(input("Enter your account number: "))
            pin = input("Enter your PIN: ")
            sender = bank.get_account(sender_acc, pin)
            if sender:
                receiver_acc = int(input("Enter recipient's account number: "))
                amount = float(input("Enter amount to transfer: "))
                receiver = bank.find_account(receiver_acc)
                if receiver:
                    sender.transfer(receiver, amount)
                else:
                    print("Recipient account not found!")
            else:
                print("Invalid credentials!")

        elif choice == "6":
            acc_num = int(input("Enter your account number: "))
            pin = input("Enter your PIN: ")
            account = bank.get_account(acc_num, pin)
            if account:
                account.display_transaction_history()
            else:
                print("Invalid credentials!")

        elif choice == "7":
            print("Exiting the system. Thank you!")
            break

        else:
            print("Invalid option! Try again.")

if __name__ == "__main__":
    main()

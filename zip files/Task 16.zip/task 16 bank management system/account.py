from transactions import Transaction
import random

class Account:
    def __init__(self, name, pin, balance=0):
        self.name = name
        self.pin = pin
        self.balance = balance
        self.account_number = random.randint(10000, 99999)
        self.transaction_history = []

    def deposit(self, amount):
        fee = amount * 0.01  # 1% deposit fee
        self.balance += amount - fee
        self.log_transaction("Deposit", amount)
        print(f"Deposit successful! Fee: ₹{fee:.2f}. New Balance: ₹{self.balance:.2f}")

    def withdraw(self, amount):
        fee = 1  # ₹1 withdrawal fee
        if self.balance >= (amount + fee):
            self.balance -= (amount + fee)
            self.log_transaction("Withdrawal", amount)
            print(f"Withdrawal successful! Fee: ₹1. New Balance: ₹{self.balance:.2f}")
        else:
            print("Insufficient funds!")



    def transfer(self, recipient, amount):
        if self.balance >= amount:
            self.balance -= amount
            recipient.balance += amount
            self.log_transaction("Transfer Out", amount)
            recipient.log_transaction("Transfer In", amount)
            print(f"Transfer successful! New Balance: ₹{self.balance:.2f}")
        else:
            print("Insufficient funds!")


    def display_details(self):
        print(f"\nAccount Details:\nName: {self.name}\nAccount Number: {self.account_number}\nBalance: ₹{self.balance:.2f}")


    def display_transaction_history(self):
        print("\nTransaction History:")
        for txn in self.transaction_history:
            print(f"{txn.type}: ₹{txn.amount:.2f} (Balance: ₹{txn.balance_after:.2f})")

    def log_transaction(self, txn_type, amount):
        txn = Transaction(txn_type, amount, self.balance)
        self.transaction_history.append(txn)

    def verify_pin(self, pin):
        return self.pin == pin


class CheckingAccount(Account):
    def __init__(self, name, pin, balance=0):
        super().__init__(name, pin, balance)
        self.overdraft_limit = 500  # Allow overdraft up to $500

    def withdraw(self, amount):
        fee = 1
        if self.balance + self.overdraft_limit >= (amount + fee):
            self.balance -= (amount + fee)
            self.log_transaction("Withdrawal", amount)
            print(f"Withdrawal successful with overdraft. Fee: $1. New Balance: ${self.balance:.2f}")
        else:
            print("Insufficient funds, even with overdraft!")


class SavingsAccount(Account):
    def __init__(self, name, pin, balance=0):
        super().__init__(name, pin, balance)
        self.interest_rate = 0.02  # 2% annual interest

    def apply_interest(self):
        interest = self.balance * (self.interest_rate / 12)
        self.balance += interest
        self.log_transaction("Interest Applied", interest)
        print(f"Interest applied: ${interest:.2f}. New Balance: ${self.balance:.2f}")

import datetime

class Transaction:
    def __init__(self, txn_type, amount, balance_after):
        self.type = txn_type
        self.amount = amount
        self.balance_after = balance_after
        self.date = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def __str__(self):
        return f"{self.date} - {self.type}: ₹{self.amount:.2f} (Balance: ₹{self.balance_after:.2f})"


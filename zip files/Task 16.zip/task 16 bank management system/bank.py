class Bank:
    def __init__(self):
        self.accounts = {}

    def add_account(self, account):
        self.accounts[account.account_number] = account

    def get_account(self, account_number, pin):
        account = self.accounts.get(account_number)
        if account and account.verify_pin(pin):
            return account
        return None

    def find_account(self, account_number):
        return self.accounts.get(account_number)

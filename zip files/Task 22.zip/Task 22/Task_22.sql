CREATE DATABASE IF NOT EXISTS companydb;
USE companydb;

CREATE TABLE employees (
    employee_id INT PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    department_id INT,
    salary DECIMAL(10,2),
    hire_date DATE,
    age INT,
    manager_id INT
);

CREATE TABLE departments (
    department_id INT PRIMARY KEY,
    department_name VARCHAR(50)
);

-- Insert some dummy data
INSERT INTO departments (department_id, department_name) VALUES
(1, 'HR'),
(2, 'IT'),
(3, 'Finance'),
(4, 'Marketing'),
(5, 'Sales');

INSERT INTO employees (employee_id, first_name, last_name, department_id, salary, hire_date, age, manager_id) VALUES
(1, 'John', 'Doe', 2, 75000, '2019-03-15', 29, NULL),
(2, 'Jane', 'Smith', 1, 50000, '2021-06-01', 35, 1),
(3, 'Jim', 'Beam', 2, 62000, '2020-02-20', 41, 1),
(4, 'Jill', 'Valentine', 3, 71000, '2018-11-10', 58, 2),
(5, 'Jack', 'Sparrow', 4, 67000, '2022-01-12', 24, NULL),
(6, 'Julia', 'Roberts', 5, 58000, '2017-09-25', 61, 3);

-- Queries

-- 1. Retrieve all columns
SELECT * FROM employees;

-- 2. List distinct departments
SELECT DISTINCT department_id FROM employees;

-- 3. Total salary
SELECT SUM(salary) AS total_salary FROM employees;

-- 4. Update salary of employee ID 10 to $60,000
UPDATE employees SET salary = 60000 WHERE employee_id = 10;

-- 5. Retrieve highest salary
SELECT MAX(salary) AS highest_salary FROM employees;

-- 6. Employees hired after Jan 1, 2020
SELECT * FROM employees WHERE hire_date > '2020-01-01';

-- 7. Count employees per department
SELECT department_id, COUNT(*) AS employee_count FROM employees GROUP BY department_id;

-- 8. Delete employees older than 60
DELETE FROM employees WHERE age > 60;

-- 9. First name, last name, department
SELECT first_name, last_name, department_id FROM employees;

-- 10. Join employees with departments
SELECT e.*, d.department_name
FROM employees e
JOIN departments d ON e.department_id = d.department_id;

-- 11. Employees with salary greater than average
SELECT * FROM employees WHERE salary > (SELECT AVG(salary) FROM employees);

-- 12. Second highest salary
SELECT MAX(salary) FROM employees WHERE salary < (SELECT MAX(salary) FROM employees);

-- 13. Employees whose name starts with 'J'
SELECT * FROM employees WHERE first_name LIKE 'J%';

-- 14. Employees without manager
SELECT * FROM employees WHERE manager_id IS NULL;

-- 15. Update department name where ID = 5
UPDATE departments SET department_name = 'Business Development' WHERE department_id = 5;

-- 16. List employees sorted by hire date descending
SELECT * FROM employees ORDER BY hire_date DESC;

-- 17. Employees in same department as employee ID 15
SELECT * FROM employees
WHERE department_id = (SELECT department_id FROM employees WHERE employee_id = 15);

-- 18. Employees who have been longest (earliest hire date)
SELECT * FROM employees ORDER BY hire_date ASC;

-- 19. Average salary by department
SELECT department_id, AVG(salary) AS average_salary FROM employees GROUP BY department_id;

-- 20. Select first 10 rows
SELECT * FROM employees LIMIT 10;

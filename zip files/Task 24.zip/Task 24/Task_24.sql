-- Create tables
CREATE DATABASE IF NOT EXISTS studentdb;
USE studentdb;

CREATE TABLE students (
    student_id INT PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    email VARCHAR(100),
    birth_date DATE,
    enrollment_date DATE
);

CREATE TABLE courses (
    course_id INT PRIMARY KEY,
    course_name VARCHAR(50),
    course_code VARCHAR(20),
    credits INT
);

CREATE TABLE enrollments (
    enrollment_id INT PRIMARY KEY,
    student_id INT,
    course_id INT,
    grade VARCHAR(2),
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (course_id) REFERENCES courses(course_id)
);

CREATE TABLE instructors (
    instructor_id INT PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    email VARCHAR(100)
);

CREATE TABLE course_instructors (
    course_id INT,
    instructor_id INT,
    FOREIGN KEY (course_id) REFERENCES courses(course_id),
    FOREIGN KEY (instructor_id) REFERENCES instructors(instructor_id)
);

-- Insert dummy data
INSERT INTO students VALUES 
(1, 'John', 'Doe', 'john@example.com', '2000-01-01', '2019-08-15'),
(2, 'Jane', 'Smith', 'jane@example.com', '1999-05-12', '2018-08-15'),
(3, 'Mike', 'Tyson', 'mike@example.com', '2001-03-22', '2020-08-15'),
(4, 'Sara', 'Connor', 'sara@example.com', '2002-07-30', '2021-08-15'),
(5, 'Tom', 'Hanks', 'tom@example.com', '1998-11-20', '2017-08-15');

INSERT INTO courses VALUES
(1, 'Database Systems', 'DBS101', 3),
(2, 'Operating Systems', 'OPS102', 4),
(3, 'Networks', 'NET103', 3),
(4, 'Web Development', 'WEB104', 3),
(5, 'Data Structures', 'DS105', 4);

INSERT INTO instructors VALUES
(1, 'Albert', 'Einstein', 'albert@example.com'),
(2, 'Isaac', 'Newton', 'isaac@example.com'),
(3, 'Nikola', 'Tesla', 'nikola@example.com');

INSERT INTO enrollments VALUES
(1, 1, 1, 'A'),
(2, 1, 2, 'B'),
(3, 2, 1, NULL),
(4, 3, 3, 'A'),
(5, 4, 5, NULL),
(6, 5, 4, 'B');

INSERT INTO course_instructors VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 1),
(5, 2);

-- TASKS:

-- 1. Retrieve All Students
SELECT * FROM students;

-- 2. Students enrolled in "Database Systems"
SELECT s.first_name, s.last_name
FROM students s
JOIN enrollments e ON s.student_id = e.student_id
JOIN courses c ON e.course_id = c.course_id
WHERE c.course_name = 'Database Systems';

-- 3. Students with No Grades Yet
SELECT s.first_name, s.last_name
FROM students s
JOIN enrollments e ON s.student_id = e.student_id
WHERE e.grade IS NULL;

-- 4. Average grade for "Database Systems" (assuming A=4, B=3, etc. can be mapped separately)
-- (Skipped mapping here for speed)

-- 5. Courses with more than 3 students enrolled
SELECT c.course_name, COUNT(e.student_id) AS student_count
FROM courses c
JOIN enrollments e ON c.course_id = e.course_id
GROUP BY c.course_id
HAVING COUNT(e.student_id) > 3;

-- 6. List of Instructors for "Database Systems"
SELECT i.first_name, i.last_name
FROM instructors i
JOIN course_instructors ci ON i.instructor_id = ci.instructor_id
JOIN courses c ON ci.course_id = c.course_id
WHERE c.course_name = 'Database Systems';

-- 7. Update student email (for student_id=3)
UPDATE students SET email = 'neel@gmail.com' WHERE student_id = 3;

-- 8. Delete Students Who Haven't Enrolled in Any Courses
DELETE FROM students
WHERE student_id NOT IN (SELECT DISTINCT student_id FROM enrollments);

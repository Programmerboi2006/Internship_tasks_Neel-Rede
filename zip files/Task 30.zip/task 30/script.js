const imageInput = document.getElementById("imageInput");
const startGameButton = document.getElementById("startGame");
const difficultySelect = document.getElementById("difficulty");
const puzzleContainer = document.getElementById("puzzle-container");
const movesCounter = document.getElementById("moves");
const timeCounter = document.getElementById("time");
const imagePreview = document.getElementById("imagePreview");

let gridSize = 3;
let imageSrc = "";
let moves = 0;
let timer;
let timeElapsed = 0;
let positions = [];
let emptyIndex;

imageInput.addEventListener("change", function (event) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function (e) {
            imageSrc = e.target.result;
            imagePreview.src = imageSrc;
        };
        reader.readAsDataURL(file);
    }
});

startGameButton.addEventListener("click", function () {
    if (!imageSrc) {
        alert("Please select an image first!");
        return;
    }
    
    gridSize = parseInt(difficultySelect.value);
    moves = 0;
    timeElapsed = 0;
    movesCounter.textContent = moves;
    timeCounter.textContent = timeElapsed;
    
    clearInterval(timer);
    timer = setInterval(() => {
        timeElapsed++;
        timeCounter.textContent = timeElapsed;
    }, 1000);
    
    createPuzzle();
});

function createPuzzle() {
    puzzleContainer.innerHTML = "";
    puzzleContainer.style.width = `${gridSize * 100}px`;
    puzzleContainer.style.height = `${gridSize * 100}px`;
    puzzleContainer.style.gridTemplateColumns = `repeat(${gridSize}, 1fr)`;
    puzzleContainer.style.gridTemplateRows = `repeat(${gridSize}, 1fr)`;

    positions = Array.from({ length: gridSize * gridSize }, (_, i) => i);
    shuffleArray(positions);

    emptyIndex = positions.indexOf(gridSize * gridSize - 1); 

    for (let i = 0; i < gridSize * gridSize; i++) {
        const piece = document.createElement("div");
        piece.classList.add("puzzle-piece");

        if (positions[i] !== gridSize * gridSize - 1) {
            piece.style.backgroundImage = `url(${imageSrc})`;
            piece.style.width = `${100}px`;
            piece.style.height = `${100}px`;
            piece.style.backgroundSize = `${gridSize * 100}px ${gridSize * 100}px`;
            piece.style.backgroundPosition = `${-(positions[i] % gridSize) * 100 / (gridSize - 1)}% ${-Math.floor(positions[i] / gridSize) * 100 / (gridSize - 1)}%`;
            piece.addEventListener("click", () => moveTile(i));
        } else {
            piece.style.background = "none";
        }

        puzzleContainer.appendChild(piece);
    }
}

function moveTile(index) {
    const row = Math.floor(index / gridSize);
    const col = index % gridSize;
    const emptyRow = Math.floor(emptyIndex / gridSize);
    const emptyCol = emptyIndex % gridSize;

    if ((Math.abs(row - emptyRow) === 1 && col === emptyCol) || (Math.abs(col - emptyCol) === 1 && row === emptyRow)) {
        swap(index, emptyIndex);
        emptyIndex = index;
        moves++;
        movesCounter.textContent = moves;

        checkWin();
    }
}

function swap(i, j) {
    const pieces = document.querySelectorAll(".puzzle-piece");
    [positions[i], positions[j]] = [positions[j], positions[i]];

    const tempPos = pieces[i].style.backgroundPosition;
    pieces[i].style.backgroundPosition = pieces[j].style.backgroundPosition;
    pieces[j].style.backgroundPosition = tempPos;
}

function checkWin() {
    if (positions.every((pos, i) => pos === i)) {
        clearInterval(timer);
        alert(`Congratulations! You solved the puzzle in ${moves} moves and ${timeElapsed} seconds!`);
    }
}

function shuffleArray(arr) {
    for (let i = arr.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [arr[i], arr[j]] = [arr[j], arr[i]];
    }
}

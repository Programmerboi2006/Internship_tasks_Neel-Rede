document.addEventListener("DOMContentLoaded", function () {
    const movieContainer = document.getElementById("movieContainer");
    const searchBar = document.getElementById("searchBar");

    const movies = [
        { 
            title: "Inception", 
            genre: "Sci-Fi", 
            year: 2010, 
            rating: "8.8", 
            image: "images/inception.jpg", 
            review: "Mind-bending! A masterpiece that keeps you on the edge of your seat."
        },
        { 
            title: "Interstellar", 
            genre: "Sci-Fi", 
            year: 2014, 
            rating: "8.6", 
            image: "images/interstellar.jpg", 
            review: "An emotional journey through space and time. A visual marvel."
        },
        { 
            title: "The Dark Knight", 
            genre: "Action", 
            year: 2008, 
            rating: "9.0", 
            image: "images/the_dark_knight.jpg", 
            review: "A gritty and thrilling masterpiece with unforgettable performances."
        },
        { 
            title: "Titanic", 
            genre: "Romance", 
            year: 1997, 
            rating: "7.8", 
            image: "images/titanic.jpg", 
            review: "A timeless love story set against the backdrop of a historic tragedy."
        },
        { 
            title: "The Godfather", 
            genre: "Crime", 
            year: 1972, 
            rating: "9.2", 
            image: "images/the_godfather.jpg", 
            review: "A legendary film that defined the gangster genre. A true cinematic masterpiece."
        },
        { 
            title: "Forrest Gump", 
            genre: "Drama", 
            year: 1994, 
            rating: "8.8", 
            image: "images/forrest_gump.jpg", 
            review: "A heartwarming and emotional story about life's ups and downs."
        },
        { 
            title: "Avengers: Endgame", 
            genre: "Action", 
            year: 2019, 
            rating: "8.4", 
            image: "images/avengers_endgame.jpg", 
            review: "The epic conclusion to the Marvel saga, packed with emotion and action."
        },
        { 
            title: "The Matrix", 
            genre: "Sci-Fi", 
            year: 1999, 
            rating: "8.7", 
            image: "images/the_matrix.jpg", 
            review: "A groundbreaking sci-fi film that changed the genre forever."
        },
        { 
            title: "Jurassic Park", 
            genre: "Adventure", 
            year: 1993, 
            rating: "8.1", 
            image: "images/jurassic_park.jpg", 
            review: "A thrilling adventure that brought dinosaurs back to life in spectacular fashion."
        },
        { 
            title: "The Shawshank Redemption", 
            genre: "Drama", 
            year: 1994, 
            rating: "9.3", 
            image: "images/the_shawshank_redemption.jpg", 
            review: "A powerful and inspiring tale of hope and friendship."
        }
    ];

    let activeCard = null;

    function displayMovies(filteredMovies) {
        movieContainer.innerHTML = "";
        filteredMovies.forEach(movie => {
            const movieCard = document.createElement("div");
            movieCard.classList.add("movie-card");
            movieCard.innerHTML = `
                <img src="${movie.image}" alt="${movie.title}">
                <h3>${movie.title}</h3>
                <p>${movie.genre} | ${movie.year}</p>
                <div class="movie-details">
                    <p>Rating: ${movie.rating}</p>
                    <p class="review">${movie.review}</p>
                </div>
            `;
            
            movieCard.addEventListener("click", function () {
                if (activeCard && activeCard !== movieCard) {
                    activeCard.classList.remove("active");
                }
                movieCard.classList.toggle("active");
                activeCard = movieCard.classList.contains("active") ? movieCard : null;
            });

            movieContainer.appendChild(movieCard);
        });
    }

    searchBar.addEventListener("input", function (event) {
        const searchText = event.target.value.toLowerCase();
        const filteredMovies = movies.filter(movie => movie.title.toLowerCase().includes(searchText));
        displayMovies(filteredMovies);
    });

    displayMovies(movies);
});

const jobs = [
    { title: "Software Engineer", company: "Google", city: "Bangalore", country: "India", category: "IT", experience: "Mid-Level", description: "Develop and maintain software solutions." },
    { title: "Marketing Manager", company: "Zomato", city: "Delhi", country: "India", category: "Marketing", experience: "Senior", description: "Lead marketing campaigns and branding initiatives." },
    { title: "UI/UX Designer", company: "Flipkart", city: "Mumbai", country: "India", category: "IT", experience: "Fresher", description: "Design user-friendly web and mobile interfaces." },
    { title: "Data Analyst", company: "Amazon", city: "Hyderabad", country: "India", category: "IT", experience: "Mid-Level", description: "Analyze data trends for business insights." },
    { title: "HR Specialist", company: "TCS", city: "Chennai", country: "India", category: "Marketing", experience: "Senior", description: "Manage recruitment and employee engagement." },
    { title: "Full Stack Developer", company: "Infosys", city: "Pune", country: "India", category: "IT", experience: "Mid-Level", description: "Develop front-end and back-end applications." },
    { title: "Content Writer", company: "Freelance", city: "Remote", country: "Online", category: "Marketing", experience: "Fresher", description: "Write blogs and social media content." },
    { title: "Cyber Security Analyst", company: "Wipro", city: "Kolkata", country: "India", category: "IT", experience: "Senior", description: "Ensure security compliance and prevent cyber threats." },
    { title: "Project Manager", company: "Accenture", city: "Remote", country: "Online", category: "IT", experience: "Senior", description: "Manage projects and coordinate with teams." }
];

let savedJobs = [];

function displayJobs(filteredJobs = jobs) {
    const jobContainer = document.getElementById("jobContainer");
    jobContainer.innerHTML = "";

    if (filteredJobs.length === 0) {
        jobContainer.innerHTML = "<p>No jobs found</p>";
        return;
    }

    filteredJobs.forEach((job, index) => {
        jobContainer.innerHTML += `
            <div class="job-card">
                <h2>${job.title}</h2>
                <p>${job.company} - ${job.city}, ${job.country}</p>
                <p>${job.description.substring(0, 50)}...</p>
                <button onclick="viewMore(${index})" class="bg-blue-500 text-white p-2 rounded mt-2">View More</button>
                <button onclick="applyJob(${index})" class="bg-yellow-500 text-white p-2 rounded mt-2">Apply Now</button>
                <button onclick="saveJob('${job.title}')" class="bg-green-500 text-white p-2 rounded mt-2">Save Job</button>
            </div>
        `;
    });
}

// Show job details in a modal
function viewMore(index) {
    const job = jobs[index];
    document.getElementById("modalJobTitle").innerText = job.title;
    document.getElementById("modalJobDescription").innerText = job.description;
    document.getElementById("jobModal").classList.remove("hidden");
}

// Apply Now button now correctly opens the modal with the job title
function applyJob(index) {
    const job = jobs[index];
    if (!job) return;

    document.getElementById("jobTitle").innerText = job.title;
    document.getElementById("applyModal").classList.remove("hidden");
}

// Close modals properly
function closeModal() {
    document.getElementById("jobModal").classList.add("hidden");
    document.getElementById("applyModal").classList.add("hidden");
}

// Submit application, show confirmation, and clear input fields
function submitApplication() {
    const name = document.getElementById("applicantName").value.trim();
    const email = document.getElementById("applicantEmail").value.trim();

    if (name === "" || email === "") {
        alert("Please enter your name and email.");
        return;
    }

    alert(`Application submitted successfully!\n\nName: ${name}\nEmail: ${email}\nFor Job: ${document.getElementById("jobTitle").innerText}`);

    document.getElementById("applicantName").value = "";
    document.getElementById("applicantEmail").value = "";

    closeModal();
}

// Reset filters and show all jobs again
function resetFilters() {
    document.getElementById("search").value = "";
    document.getElementById("locationFilter").value = "";
    document.getElementById("categoryFilter").value = "";
    document.getElementById("experienceFilter").value = "";
    displayJobs(jobs);
}

// Save job feature works properly
function saveJob(title) {
    if (!savedJobs.includes(title)) {
        savedJobs.push(title);
        alert(`Job saved: ${title}`);
    } else {
        alert("Job already saved.");
    }
}

// Filtering function now works correctly
function filterJobs() {
    const search = document.getElementById("search").value.toLowerCase();
    const location = document.getElementById("locationFilter").value.toLowerCase();
    const category = document.getElementById("categoryFilter").value;
    const experience = document.getElementById("experienceFilter").value;

    const filtered = jobs.filter(job =>
        (job.title.toLowerCase().includes(search) || search === "") &&
        (job.city.toLowerCase().includes(location) || job.country.toLowerCase().includes(location) || location === "") &&
        (job.category === category || category === "") &&
        (job.experience === experience || experience === "")
    );

    displayJobs(filtered);
}

// Ensure jobs load properly on page load
window.onload = function () {
    displayJobs(jobs);
};

-- Step 1: Create Database
CREATE DATABASE ecommerce;
USE ecommerce;

-- Step 2: Create Tables
CREATE TABLE Products (
    product_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255),
    category VARCHAR(100),
    price DECIMAL(10,2),
    stock_quantity INT
);

CREATE TABLE Customers (
    customer_id INT PRIMARY KEY AUTO_INCREMENT,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    email VARCHAR(255) UNIQUE,
    registration_date DATE
);

CREATE TABLE Orders (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    customer_id INT,
    order_date DATETIME,
    status ENUM('pending', 'shipped', 'delivered', 'canceled'),
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id)
);

CREATE TABLE Order_Items (
    order_item_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT,
    product_id INT,
    quantity INT,
    total_price DECIMAL(10,2),
    FOREIGN KEY (order_id) REFERENCES Orders(order_id),
    FOREIGN KEY (product_id) REFERENCES Products(product_id)
);

CREATE TABLE Payments (
    payment_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT,
    payment_date DATETIME,
    amount DECIMAL(10,2),
    payment_method ENUM('credit_card', 'paypal', 'bank_transfer'),
    FOREIGN KEY (order_id) REFERENCES Orders(order_id)
);

-- Step 3: Insert Sample Data
INSERT INTO Products (name, category, price, stock_quantity) VALUES
('Laptop', 'Electronics', 1000.00, 50),
('Headphones', 'Electronics', 200.00, 150),
('Smartphone', 'Electronics', 800.00, 75),
('Desk Chair', 'Furniture', 150.00, 20),
('Monitor', 'Electronics', 300.00, 30);

INSERT INTO Customers (first_name, last_name, email, registration_date) VALUES
('Alice', 'Smith', 'alice@example.com', '2024-01-10'),
('Bob', 'Johnson', 'bob@example.com', '2023-11-22'),
('Charlie', 'Brown', 'charlie@example.com', '2024-02-15');

INSERT INTO Orders (customer_id, order_date, status) VALUES
(1, '2024-03-01 10:30:00', 'delivered'),
(2, '2024-03-02 14:00:00', 'shipped'),
(1, '2024-03-05 16:20:00', 'pending');

INSERT INTO Order_Items (order_id, product_id, quantity, total_price) VALUES
(1, 1, 1, 1000.00),
(1, 2, 2, 400.00),
(2, 3, 1, 800.00),
(3, 4, 1, 150.00);

INSERT INTO Payments (order_id, payment_date, amount, payment_method) VALUES
(1, '2024-03-01 11:00:00', 1400.00, 'credit_card'),
(2, '2024-03-02 14:30:00', 800.00, 'paypal');

-- Step 4: Advanced Queries
-- 1. Top 5 Best-Selling Products
SELECT product_id, name, SUM(quantity) AS total_sold 
FROM Order_Items 
JOIN Products USING(product_id) 
GROUP BY product_id, name 
ORDER BY total_sold DESC 
LIMIT 5;

-- 2. Total Revenue for Last 6 Months
SELECT SUM(amount) AS total_revenue 
FROM Payments 
WHERE payment_date >= NOW() - INTERVAL 6 MONTH;

-- 3. Customers Who Placed More Than 10 Orders
SELECT customer_id, COUNT(order_id) AS order_count 
FROM Orders 
GROUP BY customer_id 
HAVING order_count > 10;

-- 4. Products That Have Never Been Purchased
SELECT * FROM Products 
WHERE product_id NOT IN (SELECT DISTINCT product_id FROM Order_Items);

-- 5. Average Order Value Per Customer
SELECT customer_id, AVG(amount) AS avg_order_value 
FROM Payments 
JOIN Orders USING(order_id) 
GROUP BY customer_id;

-- 6. Month With Highest Sales in Last 2 Years
SELECT DATE_FORMAT(order_date, '%Y-%m') AS month, SUM(amount) AS total_sales 
FROM Orders 
JOIN Payments USING(order_id) 
WHERE order_date >= NOW() - INTERVAL 2 YEAR 
GROUP BY month 
ORDER BY total_sales DESC 
LIMIT 1;

-- 7. Customers Who Haven't Ordered in the Last 12 Months
SELECT customer_id, first_name, last_name 
FROM Customers 
WHERE customer_id NOT IN (
    SELECT DISTINCT customer_id FROM Orders 
    WHERE order_date >= NOW() - INTERVAL 12 MONTH
);

-- 8. Most Popular Payment Method
SELECT payment_method, COUNT(*) AS usage_count 
FROM Payments 
GROUP BY payment_method 
ORDER BY usage_count DESC 
LIMIT 1;

-- Step 5: Additional Challenges
-- Stored Procedure to Update Stock When Order is Placed
DELIMITER //
CREATE PROCEDURE UpdateStock(order_id INT)
BEGIN
    UPDATE Products p
    JOIN Order_Items oi ON p.product_id = oi.product_id
    SET p.stock_quantity = p.stock_quantity - oi.quantity
    WHERE oi.order_id = order_id;
END //
DELIMITER ;

-- Trigger to Cancel Order if Payment Fails
DELIMITER //
CREATE TRIGGER CancelOrderOnPaymentFailure
AFTER INSERT ON Payments
FOR EACH ROW
BEGIN
    IF NEW.amount <= 0 THEN
        UPDATE Orders SET status = 'canceled' WHERE order_id = NEW.order_id;
    END IF;
END //
DELIMITER ;

-- View for Customer Purchase History
CREATE VIEW Customer_Purchase_History AS
SELECT c.customer_id, c.first_name, c.last_name, o.order_id, o.order_date, o.status, p.amount
FROM Customers c
JOIN Orders o ON c.customer_id = o.customer_id
JOIN Payments p ON o.order_id = p.order_id;

-- Index Strategy
CREATE INDEX idx_orders_customer ON Orders(customer_id);
CREATE INDEX idx_order_items_product ON Order_Items(product_id);
CREATE INDEX idx_payments_order ON Payments(order_id);
